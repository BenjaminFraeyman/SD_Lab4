﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Diagnostics;

namespace Labo4
{
    public enum LaboNamen { Quit = 0, Labo1, Labo2, Labo3 }
    public enum LaboDeel { Back, Deel1, Deel2, Deel3, Deel4, Deel5, Deel6, Deel7, Deel8, Deel9, LaboMenu = -1}
    
    class Program
    {
        // benodigde tijd: 10h
        // geheel hermaakt na de labosessie
        static void Main()
        {
            // Elk menu is een Laboonderdeel
            // Achter elk menu volgen de submenus
            // Achter de submenus volgen de commandos die het (sub)menu bevat
            Menu Labo1 = new Menu(LaboNamen.Labo1, LaboDeel.LaboMenu); // menu labo1
            Labo1.AddCommand(new Command1_1(LaboNamen.Labo1, LaboDeel.Deel1));
            Menu Deel2 = new Menu(LaboNamen.Labo1, LaboDeel.Deel2);// submenu deel2
            Deel2.AddCommand(new Command1_2(LaboNamen.Labo1, LaboDeel.Deel1));
            Deel2.AddCommand(new Command1_2b(LaboNamen.Labo1, LaboDeel.Deel2));
            Deel2.AddCommand(new StopReturnCommand(LaboNamen.Labo1, LaboDeel.Back));
            Labo1.AddCommand(Deel2); // toevoegen submenu deel2 aan labo1
            Menu Deel3 = new Menu(LaboNamen.Labo1, LaboDeel.Deel3);// submenu deel3
            Deel3.AddCommand(new Command1_3(LaboNamen.Labo1, LaboDeel.Deel1));
            Deel3.AddCommand(new Command1_3b(LaboNamen.Labo1, LaboDeel.Deel2));
            Deel3.AddCommand(new StopReturnCommand(LaboNamen.Labo1, LaboDeel.Back));
            Labo1.AddCommand(Deel3);// toevoegen submenu deel3 aan labo1  
            // indien je wil testen of een submenu van een submenu ook werkt:
            //Deel2.AddCommand(Deel3);
            Menu Deel4 = new Menu(LaboNamen.Labo1, LaboDeel.Deel4);// submenu deel4
            Deel4.AddCommand(new Command1_4(LaboNamen.Labo1, LaboDeel.Deel1));
            Deel4.AddCommand(new Command1_4b(LaboNamen.Labo1, LaboDeel.Deel2));
            Deel4.AddCommand(new StopReturnCommand(LaboNamen.Labo1, LaboDeel.Back));
            Labo1.AddCommand(Deel4);// toevoegen submenu deel4 aan labo1
            Menu Deel5 = new Menu(LaboNamen.Labo1, LaboDeel.Deel5);// submenu deel5
            Deel5.AddCommand(new Command1_5(LaboNamen.Labo1, LaboDeel.Deel1));
            Deel5.AddCommand(new Command1_5b(LaboNamen.Labo1, LaboDeel.Deel2));
            Deel5.AddCommand(new StopReturnCommand(LaboNamen.Labo1, LaboDeel.Back));
            Labo1.AddCommand(Deel5);// toevoegen submenu deel5 aan labo1
            Labo1.AddCommand(new Command1_6(LaboNamen.Labo1, LaboDeel.Deel6));
            Labo1.AddCommand(new Command1_7(LaboNamen.Labo1, LaboDeel.Deel7));
            Labo1.AddCommand(new Command1_8(LaboNamen.Labo1, LaboDeel.Deel8));
            Labo1.AddCommand(new Command1_9(LaboNamen.Labo1, LaboDeel.Deel9));
            Labo1.AddCommand(new StopReturnCommand(LaboNamen.Labo1, LaboDeel.Back));

            Menu Labo2 = new Menu(LaboNamen.Labo2, LaboDeel.LaboMenu); // menu labo2
            Labo2.AddCommand(new Command2_1(LaboNamen.Labo2, LaboDeel.Deel1));
            Labo2.AddCommand(new Command2_2(LaboNamen.Labo2, LaboDeel.Deel2));
            Labo2.AddCommand(new Command2_3(LaboNamen.Labo2, LaboDeel.Deel3));
            Labo2.AddCommand(new Command2_4(LaboNamen.Labo2, LaboDeel.Deel4));
            Labo2.AddCommand(new Command2_5(LaboNamen.Labo2, LaboDeel.Deel5));
            Labo2.AddCommand(new StopReturnCommand(LaboNamen.Labo2, LaboDeel.Back));

            Menu Labo3 = new Menu(LaboNamen.Labo3, LaboDeel.LaboMenu); // menu labo3
            Labo3.AddCommand(new Command3_1(LaboNamen.Labo3, LaboDeel.Deel1));
            Labo3.AddCommand(new Command3_3(LaboNamen.Labo3, LaboDeel.Deel3));
            Labo3.AddCommand(new StopReturnCommand(LaboNamen.Labo3, LaboDeel.Back));

            Menu StopOfTerug = new Menu(LaboNamen.Quit, LaboDeel.LaboMenu);

            Menu Labolijst = new Menu(LaboNamen.Quit, LaboDeel.LaboMenu); // lijst van alle labos
            Labolijst.AddCommand(Labo1);
            Labolijst.AddCommand(Labo2);
            Labolijst.AddCommand(Labo3);
            Labolijst.AddCommand(StopOfTerug);

            Boolean running = true;
            while (running)
            {
                Console.WriteLine("Toets het nummer in van het labo dat u wenst uit te voeren."); // handleiding
                Labolijst.Run(); //print lijst van labos af
                LaboNamen Choice = (LaboNamen)Convert.ToInt32(Console.ReadLine()); // keuze van labo
                if (Choice != LaboNamen.Quit) // indien u niet kiest om te stoppen
                {
                    foreach (Menu ChosenLabo in Labolijst.LaboCommandos)
                    {
                        if (ChosenLabo.Name == Choice) // kijken welk labo u koos
                        {
                            SubMenuPrint((Menu)ChosenLabo); // uitprinten submenus
                        }
                    }                  
                }
                else { running = false; }// anders programma stoppen     
            }
        }

        public static void SubMenuPrint(Menu ChosenLabo)
        {
            Boolean running2 = true;
            while (running2)
            {
                Console.WriteLine("Toets het nummer in van het labo-onderdeel dat u wenst uit te voeren."); // handleiding
                ChosenLabo.Run(); // submenu uitprinten
                LaboDeel Choice2 = (LaboDeel)Convert.ToInt32(Console.ReadLine()); // keuze welk deel van het labo u wil
                if (Choice2 != LaboDeel.Back) // indien u niet wenst terug te keren
                {
                    foreach (ICommand ChosenCommand in ChosenLabo.LaboCommandos)
                    {
                        if (ChosenCommand.Part == Choice2) // als het commando gevonden wordt
                        {
                            if (ChosenCommand is Menu) // indien u gekozen commando een menu is
                            {
                                SubMenuPrint((Menu)ChosenCommand); // herhaal u de vorige stappen
                            }
                            else ChosenCommand.Run(); // anders voert het commando zich uit
                        }
                    }
                }
                else { running2 = false; } // anders keert u terug
            }
        }
    }
}