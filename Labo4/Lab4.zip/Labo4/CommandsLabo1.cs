﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo4
{
    // Omdat ik voor mijn labonamen steeds "Labo(nummer)_(nummer)" gebruik,
    // is er een manier om de 2 nummers te kiezen en die dan te combineren tot 
    // "Labo(nummer)_(nummer).Program.Main();" ?

    class Command1_1 : ICommand
    {
        public Command1_1(LaboNamen name, LaboDeel part) : base(name, part) { }
        public override void Run() { Labo1_1.Program.Main(); }
    }
    class Command1_2 : ICommand
    {
        public Command1_2(LaboNamen name, LaboDeel part) : base(name, part) { }
        public override void Run() { Labo1_2.Program.Main(); }
    }
    class Command1_2b : ICommand
    {
        public Command1_2b(LaboNamen name, LaboDeel part) : base(name, part) { }
        public override void Run() { Labo1_2b.Program.Main(); }
    }
    class Command1_3 : ICommand
    {
        public Command1_3(LaboNamen name, LaboDeel part) : base(name, part) { }
        public override void Run() { Labo1_3.Program.Main(); }
    }
    class Command1_3b : ICommand
    {
        public Command1_3b(LaboNamen name, LaboDeel part) : base(name, part) { }
        public override void Run() { Labo1_3b.Program.Main(); }
    }
    class Command1_4 : ICommand
    {
        public Command1_4(LaboNamen name, LaboDeel part) : base(name, part) { }
        public override void Run() { Labo1_4a.Program.Main(); }
    }
    class Command1_4b : ICommand
    {
        public Command1_4b(LaboNamen name, LaboDeel part) : base(name, part) { }
        public override void Run() { Labo1_4b.Program.Main(); }
    }
    class Command1_5 : ICommand
    {
        public Command1_5(LaboNamen name, LaboDeel part) : base(name, part) { }
        public override void Run() { Labo1_5a.Program.Main(); }
    }
    class Command1_5b : ICommand
    {
        public Command1_5b(LaboNamen name, LaboDeel part) : base(name, part) { }
        public override void Run() { Labo1_5b.Program.Main(); }
    }
    class Command1_6 : ICommand
    {
        public Command1_6(LaboNamen name, LaboDeel part) : base(name, part) { }
        public override void Run() { Labo1_6.Program.Main(); }
    }
    class Command1_7 : ICommand
    {
        public Command1_7(LaboNamen name, LaboDeel part) : base(name, part) { }
        public override void Run() { Labo1_7.Program.Main(); }
    }
    class Command1_8 : ICommand
    {
        public Command1_8(LaboNamen name, LaboDeel part) : base(name, part) { }
        public override void Run() { Labo1_8.Program.Main(); }
    }
    class Command1_9 : ICommand
    {
        public Command1_9(LaboNamen name, LaboDeel part) : base(name, part) { }
        public override void Run() { Labo1_9_Sorteren.Program.Main(); }
    }
}