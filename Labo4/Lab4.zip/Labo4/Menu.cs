﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo4
{
    class Menu : ICommand
    {
        public List<ICommand> LaboCommandos { get; private set; }
        public Menu(LaboNamen naam, LaboDeel deel) : base(naam, deel)
        {
            LaboCommandos = new List<ICommand>();
        }
        public void AddCommand(ICommand command)
        { LaboCommandos.Add(command); }
        public override void Run()
        {
            Console.WriteLine("~+~+~+~+~+~+");
            foreach (ICommand command in LaboCommandos)
            {
                if (command.Part == LaboDeel.LaboMenu)
                { Console.WriteLine((int)command.Name + ": " + command.Name); }
                else Console.WriteLine((int)command.Part + ": " + command.Part);
            }
            Console.WriteLine("~+~+~+~+~+~+");
        }
    }
}