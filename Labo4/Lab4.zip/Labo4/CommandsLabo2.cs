﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Labo4
{
    // Omdat ik voor mijn labonamen steeds "Labo(nummer)_(nummer)" gebruik,
    // is er een manier om de 2 nummers te kiezen en die dan te combineren tot 
    // "Labo(nummer)_(nummer).Program.Main();" ?

    class Command2_1 : ICommand
    {
        public Command2_1(LaboNamen name, LaboDeel part) : base(name, part) { }
        public override void Run() { Labo2_1.Program.Main(); }
    }
    class Command2_2 : ICommand
    {
        public Command2_2(LaboNamen name, LaboDeel part) : base(name, part) { }
        public override void Run() { Labo2_2.Program.Main(); }
    }
    class Command2_3 : ICommand
    {
        public Command2_3(LaboNamen name, LaboDeel part) : base(name, part) { }
        public override void Run() { Labo2_3_Complexegetallen.Program.Main(); }
    }
    class Command2_4 : ICommand
    {
        public Command2_4(LaboNamen name, LaboDeel part) : base(name, part) { }
        public override void Run() { Labo2_3b.Program.Main(); }
    }
    class Command2_5 : ICommand
    {
        public Command2_5(LaboNamen name, LaboDeel part) : base(name, part) { }
        public override void Run() { Labo2_5.Program.Main(); }
    }
}