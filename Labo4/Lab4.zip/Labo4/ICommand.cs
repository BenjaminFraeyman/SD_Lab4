﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo4
{
    abstract class ICommand
    {
        public LaboDeel Part { get; private set; } // tot welk deel je commando hoort
        public LaboNamen Name { get; private set; } // tot welk labo je commando behoort
        public ICommand(LaboNamen name, LaboDeel part) // constructor
        {
            Part = part;
            Name = name;
        }
        public abstract void Run(); // methode die dient te worden ingevoegd in klassen die hiervan overerven
    }
}