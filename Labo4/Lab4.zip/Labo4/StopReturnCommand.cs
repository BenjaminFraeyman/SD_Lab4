﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo4
{
    // om een commando te kunnen toe voegen die je aan de waarde 0 koppelt
    class StopReturnCommand : ICommand
    {
        public StopReturnCommand(LaboNamen name, LaboDeel part) : base(name, part) { }
        public override void Run() { }
    }
}