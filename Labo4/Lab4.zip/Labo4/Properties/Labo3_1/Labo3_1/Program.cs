﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo3_1
{
    public class Program
    {
        public static void Main()
        {
            // Default values
            Lichtpunt Nlicht = new Lichtpunt("Ingang", "Off");
            Dimbaarlichtpunt Dlicht = new Dimbaarlichtpunt("Living", "Off", 0);
            RGBlichtpunt RGB = new RGBlichtpunt("Setup", "Off", 0, "Zwart");
            int[] gang1 = new int[3] { 0, 0, 0 };
            Multilichtpunt Punt1 = new Multilichtpunt("Gang1", "Off", gang1);
            List<Lichtpunt> Lichten = new List<Lichtpunt>();
            Lichten.Add(Nlicht);
            Lichten.Add(Dlicht);
            Lichten.Add(RGB);
            Lichten.Add(Punt1);
            // ------------------

            Console.WriteLine("ALLE LICHTEN UIT"); // alle lichten uit plaatsen
            foreach (Lichtpunt licht in Lichten)
            {
                if (licht is Multilichtpunt)
                {
                    Multilichtpunt temp = (Multilichtpunt)licht;
                    for (int i = 0; i < temp.Toestand.Length; i++)
                    { temp.Changegang(temp, i, 0); }
                }
                else
                { licht.ChangeValue("Off", licht); }
            }
            Console.WriteLine();
            Lichtpunt.Display(Lichten);

            Console.WriteLine();
            Console.WriteLine("ALLE LICHTEN AAN"); 
            foreach (Lichtpunt licht in Lichten)
            {
                if (licht is Multilichtpunt)
                {
                    Multilichtpunt temp = (Multilichtpunt)licht;
                    for (int i = 0; i < temp.Toestand.Length; i++)
                    { temp.Changegang(temp, i, 1); }
                }
                else
                { licht.ChangeValue("On", licht); }
            }
            Console.WriteLine();
            Lichtpunt.Display(Lichten);
            Console.WriteLine();

            Console.WriteLine("ALLE RGBLICHTEN OP ROOD");
            foreach (Lichtpunt licht in Lichten)
            {
                if (licht is RGBlichtpunt)
                {
                    RGBlichtpunt temp = (RGBlichtpunt) licht;
                    temp.veranderkleur(temp, "rood");
                }
            }
            Console.WriteLine();
            Lichtpunt.Display(Lichten);
            Console.WriteLine();

            Console.WriteLine("ALLE DIMLICHTEN OP 50%");
            foreach (Lichtpunt licht in Lichten)
            {
                if (licht is Dimbaarlichtpunt)
                {
                    Dimbaarlichtpunt temp = (Dimbaarlichtpunt)licht;
                    temp.percentage(temp, 50);
                }
            }
            Console.WriteLine();
            Lichtpunt.Display(Lichten);
            Console.WriteLine();

            Console.WriteLine("EEN LICHT PER GANG AANPASSEN");
            Punt1.Changegang(Punt1, 2, 0);
            Console.WriteLine();
            Lichtpunt.Display(Lichten);
            Console.ReadLine();
        }
    }
}
// benodigde tijd : 9h + ingekort in labo in 30 minuten