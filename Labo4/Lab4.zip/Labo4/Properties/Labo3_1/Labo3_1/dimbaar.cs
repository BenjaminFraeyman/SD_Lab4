﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo3_1
{
    class Dimbaarlichtpunt : Lichtpunt
    {
        public int Percentage { get; private set; } // hoeveel % aan (dimbaar)
        public Dimbaarlichtpunt(string naam, string toestand, int percent) : base (naam, toestand)
        {
            Percentage = percent;
        }
        public override string ToString()
        {
            return Naam + " - " + Toestand + " - " + Percentage;
        }

        public void percentage(Dimbaarlichtpunt licht, int percent)
        {
            licht.Percentage = percent;
            Console.WriteLine("value changed: " + licht);
        }
    }
}
