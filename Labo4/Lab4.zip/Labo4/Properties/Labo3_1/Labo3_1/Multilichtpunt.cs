﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo3_1
{
    class Multilichtpunt : Lichtpunt
    {
        public int[] Toestanden { get; private set; }
        public Multilichtpunt(string naam, string toestand, int[] toestanden) : base(naam, toestand)
        {
            Toestanden = toestanden;
        }

        public void MultiDisplay(Multilichtpunt licht)
        {
            foreach (int toestand in licht.Toestanden)
            {
                Console.WriteLine(Naam + " - " + toestand);
            }
        }

        public void Changegang(Multilichtpunt licht, int plaats, int toestand)
        {
            licht.Toestanden[plaats] = toestand;
            Console.WriteLine("value changed: " + Naam + " - " + licht.Toestanden[plaats]);
        }

    }
}
