﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo3_3
{
    class NormalDice : Dice
    {
        Random random = new Random();
        public NormalDice(int zijden) : base(zijden) // constructor
        {  }

        public override int ThrowDice()
        {
            int Throw = random.Next(1, Zijden + 1); // zijden +1 omdat je anders een waarde terugkrijgt tussen 1 en (zijden-1)
            Console.WriteLine("U wierp: {0} (zijden: {1})", Throw, Zijden);
            return Throw;
            
        }
        public override string ToString()
        { return Convert.ToString(Zijden); }
    }
}