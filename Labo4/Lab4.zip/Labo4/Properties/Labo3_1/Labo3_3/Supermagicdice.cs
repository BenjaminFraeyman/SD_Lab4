﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo3_3
{
    class Supermagicdice : Dice
    {
        Random random = new Random();
        public Supermagicdice(int zijden) : base(zijden)// constructor
        { }

        public override int ThrowDice()
        {
            int Throw = random.Next(1, (Zijden + 1));
            if (Throw == Zijden)
            {
                int temp = Zijden * 2;
                Zijden = temp;
            }
            if (Throw == 1) // indien een 1 geworpen wordt
            {
                if (Zijden > 2) // als het aantal zijden groter is dan 2
                {
                    int temp = Zijden / 2; // deel het aantal zijden door 2
                    Zijden = temp;
                }
                else // zijden = 1 of 2
                {
                    int temp = 2; // aantal zijden wordt een 2
                    Zijden = temp;
                }
            }
            Console.WriteLine("U wierp: {0} (zijden: {1})", Throw, Zijden);
            return Throw;
        }

        public override string ToString()
        { return Convert.ToString(Zijden); }
    }
}