﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo2_4_Domotica
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("BENODIGDE TIJD: tussen 5 en 6 uur");
            Boolean stop = true;
            while (stop)
            {
                string[] input = { "ja", "nee" };
                Console.WriteLine("Lichtsturing? (ja of nee)"); // keuze lichtsturing
                string uitkomst = Convert.ToString(Console.ReadLine());
                if (uitkomst == input[0])// ja
                {
                    lichtsturing();
                }
                if (uitkomst == input[1])// nee
                {
                    Console.WriteLine("Toestellen aansturen? (ja of nee)"); // keuze toestelsturing
                    string uitkomst2 = Convert.ToString(Console.ReadLine());
                    if (uitkomst2 == input[0])// ja
                    {
                        toestelsturing();
                    }
                }
                Console.WriteLine("Stoppen? (ja of nee)"); // keuze lichtsturing
                string stoppen = Convert.ToString(Console.ReadLine());
                if (stoppen == input[0])// ja
                {
                    stop = false;
                }
            }
        }

        static void lichtsturing()
        {
            // (MBV class Lichtpunten (Lichtpunten.cs))
            Boolean bezig = true;
            while (bezig)
            {
                Console.WriteLine("Geef een kamer op (vb: slaapkamer, keuken, woonkamer, badkamer)");
                string Kam = Console.ReadLine();
                Console.WriteLine("Geef de toestand op (aan of uit)");
                string Toe = Convert.ToString(Console.ReadLine());
                Lichtpunten kamer1 = new Lichtpunten(Kam, Toe);
                Console.WriteLine(kamer1);
                Console.ReadLine();
                bezig = false;
            }
        }

        static void toestelsturing()
        {
            // (MBV class Toestellen (Toestellen.cs))
            Boolean bezig = true;
            while (bezig)
            {
                int maximum = 250; // in te stellen vooraf
                int minimum = 0; // in te stellen vooraf
                Console.WriteLine("Geef een kamer op (vb: slaapkamer, keuken, woonkamer, badkamer)");
                string Kam = Console.ReadLine();
                Console.WriteLine("Geef een toestel op");
                string Toes = Console.ReadLine();
                Console.WriteLine("Geef de temperatuur waarop u deze wilt instellen (0-250)");
                int Waa = Convert.ToInt32(Console.ReadLine());
                if (Waa > maximum || Waa < minimum)
                {
                    Console.WriteLine("ERROR BUITEN TOEGELATEN WAARDES");
                }
                else
                {
                    Toestellen toestel1 = new Toestellen(Kam, Toes, Waa);
                    toestel1 = new Toestellen(Kam, Toes, Waa);
                    Console.WriteLine(toestel1);
                    Console.ReadLine();
                    bezig = false;
                }
            }        
        }
    }
}
