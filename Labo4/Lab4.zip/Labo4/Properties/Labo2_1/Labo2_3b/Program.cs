﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo2_3b
{
    public class Program
    {
        // (klasses waar getal ingeplaatst word staat in getal.cs bestand)

        public static void Main()
        {
            Console.WriteLine("BENODIGDE TIJD: tussen 1 en 2 uur");

            Console.WriteLine("Geef getal1 in (gesplitst met ; (vb. 2;3,5))");
            var getal1 = Console.ReadLine();
            var getalLijst1 = getal1.Split(';');
            double deel11 = Convert.ToDouble(getalLijst1[0]);
            double deel12 = Convert.ToDouble(getalLijst1[1]);
            Complex number1 = new Complex(deel11, deel12);

            Console.WriteLine("Geef getal2 in (gesplitst met ; (vb. 2;3,5))");
            var getal2 = Console.ReadLine();
            var getalLijst2 = getal2.Split(';');
            double deel21 = Convert.ToDouble(getalLijst2[0]);
            double deel22 = Convert.ToDouble(getalLijst2[1]);
            Complex number2 = new Complex(deel21, deel22);

            Console.WriteLine("De getallen zijn");
            Console.WriteLine(number1);
            Console.WriteLine(number2);

            // oproep som
            Console.WriteLine("De som is");
            Complex number3 = ComplexHelper.Add(number1, number2);
            Console.WriteLine(number3);

            // oproep aftrekking
            Console.WriteLine("De aftrekking is");
            Complex number4 = ComplexHelper.Min(number1, number2);
            Console.WriteLine(number4);

            // oproep product
            Console.WriteLine("Het product is");
            Complex number5 = ComplexHelper.Maal(number1, number2);
            Console.WriteLine(number5);

            // oproep deling
            Console.WriteLine("De deling is");
            Complex number6 = ComplexHelper.Delen(number1, number2);
            Console.WriteLine(number6);

            Console.ReadLine();
        }
    }
}
