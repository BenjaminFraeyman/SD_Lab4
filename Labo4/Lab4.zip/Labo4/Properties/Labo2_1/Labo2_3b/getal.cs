﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo2_3b
{
    class Complex
    {
        public double Real { get; private set; }
        public double Imaginary { get; private set; }

        public Complex(double Re, double Im) // constructor
        {
            Real = Re;
            Imaginary = Im;
        }
        public override string ToString() // getal uitgeven
        {
            return (" " + Real + "+ (" + Imaginary + "i)");
        }
    }
}
