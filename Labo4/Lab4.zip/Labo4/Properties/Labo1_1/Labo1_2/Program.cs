﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo1_2
{
    public class Program
    {
        public static void Main()
        {
            Console.WriteLine("Basis?");
            int basis; // aanmaak opslagplaats
            basis = Convert.ToInt32(Console.ReadLine()); // input basis
            Console.WriteLine("Lengte?");
            int lengte; // aanmaak opslagplaats
            lengte = Convert.ToInt32(Console.ReadLine()); // input lengte
            Console.WriteLine("Hoogte?");
            int hoogte; // aanmaak opslagplaats
            hoogte = Convert.ToInt32(Console.ReadLine()); // input hoogte

            int inhoud;
            inhoud = basis * lengte * hoogte; // berekening

            Console.WriteLine("De inhoud is {0}", inhoud); // output
            Console.ReadLine();
        }
    }
}

// BENODIGDE TIJD
// 10 minuten (ging vlot na de eerste oefening gemaakt te hebben)