﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo1_5a
{
    public class Program
    {
        public static void Main()
        {
            while (true)
            {
                Console.WriteLine("welk nummer wilt u de faculteit van berekenen?");
                uint nummer = Convert.ToUInt32(Console.ReadLine());
                ulong berekend = Factorial(nummer); //aanroepen methode
                Console.WriteLine("de faculteit is {0}", berekend); // output
                
            }           
        }

        static ulong Factorial(uint nummer)
        {
            ulong resultaat = 1;
            for (uint i = 1; i <= nummer; i++) //elk element vermenigvuldigen met elkaar
            {
                resultaat *= i;
            }
            return resultaat;
        }
    }
}

// BENODIGDE TIJD
// 10 minuten