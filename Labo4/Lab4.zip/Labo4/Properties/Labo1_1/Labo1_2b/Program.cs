﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo1_2b
{
    public class Program
    {
        public static void Main()
        {
            Console.WriteLine("Hoogte?");
            double hoogte;
            hoogte = Convert.ToInt32(Console.ReadLine()); // input hoogte

            Console.WriteLine("Straal?");
            double straal;
            straal = Convert.ToInt32(Console.ReadLine()); // input straal

            double inhoud;
            inhoud = straal * straal * hoogte * Math.PI; // berekening

            Console.WriteLine("de inhoud is {0}", inhoud); // output
            Console.ReadLine();
        }
    }
}

// BENODIGDE TIJD
// 5 minuten
