﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo1_8
{
    public class Program
    {
        public static void Main()
        {
            Console.WriteLine("geef maximum waarde op");
            int max;
            max = Convert.ToInt32(Console.ReadLine()); // max waarde
            int[] startgetallen = new int[max];
            for (int i = 1; i < startgetallen.Length; i++) // aanmaak array met alle elementen van 0 tot max
            {
                startgetallen[i - 1] = i + 1;
            }
            int aantal = Priem(startgetallen); // aantal priemgetallen tussen 0 en max

            int[] priemgetallen = Priemgetallen(startgetallen, aantal); // aanmaak array met alle priemgetallen

            foreach (var item in priemgetallen) // uitschrijven array
            {
                Console.Write(item + " ");
            }
            Console.ReadLine();
        }

        static int Priem(int[] startgetallen)
        {
            bool isPrime = true;
            int aantal = 0;
            for (int i = 2; i <= startgetallen.Length; i++) // voor alle elementen
            {
                for (int j = 2; j <= startgetallen.Length; j++) // delen door alle getallen
                {
                    if (i != j && i % j == 0) // indien niet gelijke getallen en % is toch 0, geen priemgetal
                    {
                        isPrime = false;
                    }
                }
                if (isPrime) // anders priemgetal
                {
                    aantal++;
                }
                isPrime = true;
            }
            return aantal;
        }

        static int[] Priemgetallen(int[] startgetallen, int aantal) // principe zelfde als eerste methode, hier schrijft hij de priemgetallen in de array
        {
            int[] priemgetallen = new int[aantal];
            for (int plaats = 0; plaats < aantal; plaats++)
            {
                bool isPrime = true;
                for (int i = 2; i <= startgetallen.Length; i++)
                {
                    for (int j = 2; j <= startgetallen.Length; j++)
                    {
                        if (i != j && i % j == 0)
                        {
                            isPrime = false;
                        }
                    }
                    if (isPrime)
                    {
                        priemgetallen[plaats] = i; // inplaatsen in array
                        plaats++;
                    }
                    isPrime = true;
                }
            }
           
            return priemgetallen;
        }
    }
}
// benodigde tijd
// +3h