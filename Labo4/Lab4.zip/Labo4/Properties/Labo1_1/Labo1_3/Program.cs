﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo1_3
{
    public class Program
    {
        public static void Main()
        {
            Console.WriteLine("Getal?");
            int getal;
            getal = Convert.ToInt32(Console.ReadLine()); // input

            Console.WriteLine(Convert.ToString(getal, 2)); // output(conversie naar basis 2)
            Console.WriteLine(Convert.ToString(getal, 16)); // output(conversie naar basis 16)                         
        }
    }
}
// BENODIGDE TIJD
// 15 minuten (met hulp van medestudent omdat ik niet wist hoe er aan te beginnen)