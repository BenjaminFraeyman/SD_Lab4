﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo1_5b
{
    public class Program
    {
        static ulong Factorial(uint nummer)
        {
            if (nummer == 1)
                return 1;
            else
                return nummer * Factorial(nummer - 1); // recursieve deel            
        }

        public static void Main()
        {
            while (true)
            {
                Console.WriteLine("welk nummer wilt u de faculteit van berekenen?");
                uint nummer = Convert.ToUInt32(Console.ReadLine());
                ulong berekend = Factorial(nummer);
                Console.WriteLine("de faculteit is {0}", berekend);
            }
        }
    }
}

// BENODIGDE TIJD
// 10 minuten