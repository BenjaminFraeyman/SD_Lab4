﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo4
{
    // Omdat ik voor mijn labonamen steeds "Labo(nummer)_(nummer)" gebruik,
    // is er een manier om de 2 nummers te kiezen en die dan te combineren tot 
    // "Labo(nummer)_(nummer).Program.Main();" ?

    class Command3_1 : ICommand
    {
        public Command3_1(LaboNamen name, LaboDeel part) : base(name, part) { }
        public override void Run() { Labo3_1.Program.Main(); }
    }
    class Command3_3 : ICommand
    {
        public Command3_3(LaboNamen name, LaboDeel part) : base(name, part) { }
        public override void Run() { Labo3_3.Program.Main(); }
    }
}